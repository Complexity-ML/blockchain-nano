set -eu
export TMPDIR=/build/pruning-schema-59fa6530-arm64/tmp
mkdir "$TMPDIR"
cd /build/finalized-retention-4734f285-arm64
clang++ -DMCL_BINT_ASM_X64=0 -DMCL_DONT_USE_XBYAK -DMCL_FP_BIT=384 -DMCL_FR_BIT=256 -DMCL_MSM=0 -DMCL_PORTABLE=1 -DMCL_USE_LLVM=1 -I/work/include -I/work/third_party -I/work/third_party/ckzg/src -I/work/third_party/ckzg/blst/bindings -I/build/finalized-retention-4734f285-arm64/third_party/ckzg/include -I/work/third_party/secp256k1/include -I/work/third_party/mcl/include -O3 -DNDEBUG -std=gnu++20 -Wall -Wextra -Wpedantic -c /work/src/storage.cpp -o /build/pruning-schema-59fa6530-arm64/storage.cpp.o > /report/storage.log 2>&1
cp /build/finalized-retention-4734f285-arm64/libnano_core.a /build/pruning-schema-59fa6530-arm64/libnano_core.a
ar rcs /build/pruning-schema-59fa6530-arm64/libnano_core.a /build/pruning-schema-59fa6530-arm64/storage.cpp.o
test "$(ar t /build/pruning-schema-59fa6530-arm64/libnano_core.a | grep -cx storage.cpp.o)" = 1
cd /build/coherent-efbeb9bc-arm64
clang++ -DMCL_BINT_ASM_X64=0 -DMCL_DONT_USE_XBYAK -DMCL_FP_BIT=384 -DMCL_FR_BIT=256 -DMCL_MSM=0 -DMCL_PORTABLE=1 -DMCL_USE_LLVM=1 -I/legacy/include -I/legacy/third_party -I/legacy/third_party/mcl/include -O3 -DNDEBUG -std=gnu++20 -c /report/legacy-reader.cpp -o /build/pruning-schema-59fa6530-arm64/legacy-reader.cpp.o > /report/legacy-compile.log 2>&1
cd /build/coherent-efbeb9bc-arm64
/usr/bin/clang++ -O3 -DNDEBUG /build/pruning-schema-59fa6530-arm64/legacy-reader.cpp.o -o /build/pruning-schema-59fa6530-arm64/legacy-reader third_party/mcl/bint64.o third_party/mcl/base64.o /build/coherent-efbeb9bc-arm64/libnano_core.a third_party/ckzg/libnano_ckzg.a third_party/ckzg/libnano_blst.a third_party/secp256k1/lib/libsecp256k1.a /usr/lib/aarch64-linux-gnu/libgmpxx.so /usr/lib/aarch64-linux-gnu/libgmp.so /usr/lib/aarch64-linux-gnu/libssl.so /usr/lib/aarch64-linux-gnu/libcrypto.so /usr/lib/aarch64-linux-gnu/libicuuc.so -ldl /usr/lib/aarch64-linux-gnu/librocksdb.so lib/libmcl.a > /report/legacy-link.log 2>&1
cd /build/finalized-retention-4734f285-arm64
clang++ -DMCL_BINT_ASM_X64=0 -DMCL_DONT_USE_XBYAK -DMCL_FP_BIT=384 -DMCL_FR_BIT=256 -DMCL_MSM=0 -DMCL_PORTABLE=1 -DMCL_USE_LLVM=1 -I/work/include -I/work/third_party -I/work/third_party/mcl/include -O3 -DNDEBUG -std=gnu++20 -c /work/tests/test_execution_checkpoint.cpp -o /build/pruning-schema-59fa6530-arm64/test.cpp.o > /report/test-compile.log 2>&1
cd /build/finalized-retention-4734f285-arm64
/usr/bin/clang++ -O3 -DNDEBUG /build/pruning-schema-59fa6530-arm64/test.cpp.o -o /build/pruning-schema-59fa6530-arm64/test third_party/mcl/bint64.o third_party/mcl/base64.o /build/pruning-schema-59fa6530-arm64/libnano_core.a third_party/ckzg/libnano_ckzg.a third_party/ckzg/libnano_blst.a third_party/secp256k1/lib/libsecp256k1.a /usr/lib/aarch64-linux-gnu/libgmpxx.so /usr/lib/aarch64-linux-gnu/libgmp.so /usr/lib/aarch64-linux-gnu/libssl.so /usr/lib/aarch64-linux-gnu/libcrypto.so /usr/lib/aarch64-linux-gnu/libicuuc.so -ldl /usr/lib/aarch64-linux-gnu/librocksdb.so lib/libmcl.a > /report/test-link.log 2>&1
/build/pruning-schema-59fa6530-arm64/test --pruning-schema /build/pruning-schema-59fa6530-arm64/legacy-reader > /report/schema.log 2>&1
/build/pruning-schema-59fa6530-arm64/test --pruning-restore > /report/restore.log 2>&1
/build/pruning-schema-59fa6530-arm64/test --pruning-corruption > /report/corruption.log 2>&1
/build/pruning-schema-59fa6530-arm64/test > /report/checkpoint.log 2>&1
sha256sum /build/pruning-schema-59fa6530-arm64/test /build/pruning-schema-59fa6530-arm64/legacy-reader /build/pruning-schema-59fa6530-arm64/libnano_core.a > /report/programs.txt
