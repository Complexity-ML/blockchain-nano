from pathlib import Path
import subprocess,shlex,json,hashlib,os
R=Path(__file__).parent;S=Path('/tmp/nano-pruning-schema-20261004');OLD=Path('/tmp/nano-production-coherent-20261004');I='sha256:e30ce85e363309a64814c300fbf07b482e28b841c8f9577cba9b4e70070d37fb';V='nano-clean-arm64-build-20261002';B='/build/finalized-retention-4734f285-arm64';L='/build/coherent-efbeb9bc-arm64';O='/build/pruning-schema-59fa6530-arm64';owner=f'{os.getuid()}:{os.getgid()}'
def save(n,v):(R/n).write_text(json.dumps(v,indent=2)+'\n')
def call(a):return subprocess.check_output(a,text=True).strip()
def inspect(args):return call(['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--mount',f'type=volume,src={V},dst=/build,readonly',I]+args)
def flags(path):
 raw=inspect(['cat',path]);return {l.split(' = ',1)[0]:shlex.split(l.split(' = ',1)[1]) for l in raw.splitlines() if ' = ' in l}
def manifest(src):return {n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in call(['git','-C',str(src),'ls-files']).splitlines()}
try:
 assert not call(['docker','ps','-q']);rev=call(['git','-C',str(S),'rev-parse','HEAD']);assert rev.startswith('59fa6530');assert not call(['git','-C',str(S),'status','--porcelain'])
 before=manifest(S);save('sources-before.json',before);baseline=inspect(['sha256sum',B+'/libnano_core.a',L+'/libnano_core.a',B+'/nano-execution-checkpoint-tests']);(R/'baseline-before.txt').write_text(baseline+'\n')
 core=flags(B+'/CMakeFiles/nano_core.dir/flags.make');tf=flags(B+'/CMakeFiles/nano-execution-checkpoint-tests.dir/flags.make');oldf=flags(L+'/CMakeFiles/nano-execution-checkpoint-tests.dir/flags.make')
 def compile(f,source,obj,old=False):return ['clang++']+f['CXX_DEFINES']+[x.replace('/work/','/legacy/') if old else x for x in f['CXX_INCLUDES']]+f['CXX_FLAGS']+['-c',source,'-o',obj]
 def link(base,obj,exe,lib):
  a=shlex.split(inspect(['cat',base+'/CMakeFiles/nano-execution-checkpoint-tests.dir/link.txt']));k='CMakeFiles/nano-execution-checkpoint-tests.dir/tests/test_execution_checkpoint.cpp.o';assert k in a;a[a.index(k)]=obj;a[a.index('-o')+1]=exe;a[a.index('libnano_core.a')]=lib;return a
 commands=[('storage',B,compile(core,'/work/src/storage.cpp',O+'/storage.cpp.o')),('legacy-compile',L,compile(oldf,'/report/legacy-reader.cpp',O+'/legacy-reader.cpp.o',True)),('legacy-link',L,link(L,O+'/legacy-reader.cpp.o',O+'/legacy-reader',L+'/libnano_core.a')),('test-compile',B,compile(tf,'/work/tests/test_execution_checkpoint.cpp',O+'/test.cpp.o')),('test-link',B,link(B,O+'/test.cpp.o',O+'/test',O+'/libnano_core.a'))]
 script='set -eu\nexport TMPDIR='+O+'/tmp\nmkdir "$TMPDIR"\n'
 for stage,cwd,args in commands:
  if stage=='legacy-compile':script+='cp '+B+'/libnano_core.a '+O+'/libnano_core.a\nar rcs '+O+'/libnano_core.a '+O+'/storage.cpp.o\ntest "$(ar t '+O+'/libnano_core.a | grep -cx storage.cpp.o)" = 1\n'
  script+='cd '+cwd+'\n'+shlex.join(args)+' > /report/'+stage+'.log 2>&1\n'
 for stage,args in [('schema',[O+'/test','--pruning-schema',O+'/legacy-reader']),('restore',[O+'/test','--pruning-restore']),('corruption',[O+'/test','--pruning-corruption']),('checkpoint',[O+'/test'])]:script+=shlex.join(args)+' > /report/'+stage+'.log 2>&1\n'
 script+='sha256sum '+O+'/test '+O+'/legacy-reader '+O+'/libnano_core.a > /report/programs.txt\n'
 (R/'run.sh').write_text(script);save('commands.json',commands)
 call(['docker','run','--rm','--network','none','--read-only','--user','0:0','--cap-drop','ALL','--cap-add','CHOWN','--mount',f'type=volume,src={V},dst=/build',I,'sh','-c','set -eu; test ! -e "$1"; mkdir "$1"; chown "$2" "$1"','sh',O,owner])
 save('state.json',{'phase':'compiling','revision':rev,'productionQualified':False})
 with (R/'controller.log').open('w') as log:r=subprocess.run(['docker','run','--rm','--name','nano-pruning-schema-arm64-20261005','--user',owner,'--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--cpus','2','--memory','3g','--tmpfs','/tmp:rw,nosuid,nodev,size=256m','--mount',f'type=volume,src={V},dst=/build','--mount',f'type=bind,src={S},dst=/work,readonly','--mount',f'type=bind,src={OLD},dst=/legacy,readonly','--mount',f'type=bind,src={R},dst=/report',I,'bash','/report/run.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 (R/'controller-exit.txt').write_text(str(r.returncode)+'\n');assert r.returncode==0,'Keep failure logs'
 after=manifest(S);save('sources-after.json',after);assert before==after;end=inspect(['sha256sum',B+'/libnano_core.a',L+'/libnano_core.a',B+'/nano-execution-checkpoint-tests']);(R/'baseline-after.txt').write_text(end+'\n');assert baseline==end
 save('state.json',{'phase':'terminal','exit':0,'revision':rev,'scenarios':['schema','restore','corruption','checkpoint'],'oldCoreRevision':'efbeb9bc','newBaseCoreRevision':'4734f285','replacedCoreObject':'storage.cpp.o','productionQualified':False})
except Exception as e:
 save('failure.json',{'error':str(e)});save('state.json',{'phase':'terminal','exit':1,'productionQualified':False});raise
