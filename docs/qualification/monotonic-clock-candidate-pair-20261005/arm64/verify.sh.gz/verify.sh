set -eu
test "$(id -u)" = 10001
test "$(id -g)" = 10001
sha256sum /usr/local/bin/nano /usr/local/bin/nano-p2p
cd /usr/local/share/nano/licenses
sha256sum -c notices.sha256
nano_libs=$(ldd /usr/local/bin/nano; ldd /usr/local/bin/nano-p2p)
! printf '%s\n' "$nano_libs" | grep -q 'not found'
/usr/local/bin/nano --help
set +e
/usr/local/bin/nano-p2p --help
nano_p2p_usage_exit=$?
set -e
test "$nano_p2p_usage_exit" = 1
printf 'verified p2p usage exit=%s\n' "$nano_p2p_usage_exit"
