set -eu
cd /build
mkdir /build/storage-compaction-6b1237a7-amd64
clang++ -std=c++20 -O2 -I/work/third_party /work/tools/storage-maintenance/compact-owned-copy.cpp -lrocksdb -lcrypto -o /build/storage-compaction-6b1237a7-amd64/compact-owned-copy > /report/compile.log 2>&1
clang++ -std=c++20 -O2 -I/work/third_party /work/tools/storage-profile/profile.cpp -lrocksdb -o /build/storage-compaction-6b1237a7-amd64/storage-profile > /report/profile-compile.log 2>&1
cd /source
find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/source-before.sha256
cd /report
cp -a /source /report/copy
chmod 700 /report/copy
/build/storage-compaction-6b1237a7-amd64/storage-profile /report/copy > /report/profile-before.json
if /build/storage-compaction-6b1237a7-amd64/compact-owned-copy --offline-owned-copy /report/copy/chain > /report/missing-marker-output.txt 2> /report/missing-marker-error.txt; then exit 31; fi
grep -q 'Explicit owned copy marker required' /report/missing-marker-error.txt
ln -s /report/copy/chain /report/chain-link
if /build/storage-compaction-6b1237a7-amd64/compact-owned-copy --offline-owned-copy /report/chain-link > /report/symlink-output.txt 2> /report/symlink-error.txt; then exit 32; fi
grep -q 'Symlink path refused' /report/symlink-error.txt
printf 'owned-offline-qualification-copy-v1\n' > /report/copy/.nano-owned-compaction-copy
/build/storage-compaction-6b1237a7-amd64/compact-owned-copy --offline-owned-copy /report/copy/chain > /report/compaction.json
/build/storage-compaction-6b1237a7-amd64/storage-profile /report/copy > /report/profile-after.json
/build/pruning-wan-092a153c-amd64/nano audit-capella /config/genesis.json /report/copy/chain /proof/audit-request.json > /report/audit-after.json
cd /source
find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/source-after.sha256
cmp /report/source-before.sha256 /report/source-after.sha256
sha256sum /build/storage-compaction-6b1237a7-amd64/compact-owned-copy /build/storage-compaction-6b1237a7-amd64/storage-profile /build/pruning-wan-092a153c-amd64/nano > /report/programs.txt
