set -eu
/build/pruning-wan-092a153c-amd64/nano audit-capella /config/genesis.json /report/copy/chain /proof/finalized-audit-request.json > /report/audit-after.json
sha256sum /proof/finalized-audit-request.json > /report/terminal-request.sha256
cd /source
find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/source-after.sha256
cmp /report/source-before.sha256 /report/source-after.sha256
sha256sum /build/storage-compaction-6b1237a7-amd64/compact-owned-copy /build/storage-compaction-6b1237a7-amd64/storage-profile /build/pruning-wan-092a153c-amd64/nano > /report/programs.txt
