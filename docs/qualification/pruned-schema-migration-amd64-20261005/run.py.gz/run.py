from pathlib import Path
import subprocess,shlex,json
r=Path(__file__).parent;image='sha256:fd9b0bb98a63963dba141a820ab7a49c08e23afcfb7b5ea9ea939987d75d6f14';volume='nano-clean-rpc-build-20261002';b='/build/finalized-retention-4734f285-amd64';o='/build/pruned-migration-23df7f63-amd64';src='/home/ubuntu/nano-pruned-migration-source-v2-20261005';fixture='/home/ubuntu/nano-qualification-muucwk44';prefix=['sudo','-n','docker']
def call(a):return subprocess.check_output(a,text=True).strip()
assert not call(prefix+['ps','-q'])
assert call(['git','-C',src,'rev-parse','--short=8','HEAD'])=='23df7f63'
assert not call(['git','-C',src,'status','--porcelain'])
call(['git','-C',src,'diff','--exit-code','59fa6530','HEAD','--','src','include','network','third_party','cmake','CMakeLists.txt'])
link=shlex.split(call(prefix+['run','--rm','--network','none','--read-only','--cap-drop','ALL','--mount',f'type=volume,src={volume},dst=/build,readonly',image,'cat',b+'/CMakeFiles/nano.dir/link.txt']))
link[link.index('CMakeFiles/nano.dir/src/main.cpp.o')]='/build/pruning-wan-092a153c-amd64/main.cpp.o';link[link.index('libnano_core.a')]='/build/pruning-schema-59fa6530-amd64/libnano_core.a';link[link.index('-o')+1]=o+'/nano'
(r/'link-command.json').write_text(json.dumps(link,indent=2)+'\n')
script='''set -eu
mkdir OUT
cd BASE
clang++ -std=c++20 -O2 -I/work/third_party /work/tools/storage-maintenance/migrate-pruned-owned-copy.cpp -lrocksdb -lcrypto -o OUT/migrate > /report/compile.log 2>&1
LINK > /report/link.log 2>&1
sha256sum /build/pruning-schema-59fa6530-amd64/libnano_core.a /build/pruning-wan-092a153c-amd64/nano > /report/baseline-before.sha256
cd /source
find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/source-before.sha256
for stage in normal before-write after-write; do
 cp -a /source "/report/$stage"
 printf 'owned-offline-schema-migration-v1\\n' > "/report/$stage/.nano-owned-schema-migration-copy"
 /build/pruning-wan-092a153c-amd64/nano audit-capella /config/genesis.json "/report/$stage/chain" /proof/finalized-audit-request.json > "/report/$stage-audit-before.json"
 if [ "$stage" = normal ]; then
  cd /report/normal
  find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/rejection-before.sha256
  if OUT/migrate --offline-owned-copy /report/normal/chain --audit-request /proof/audit-request.json > /report/wrong-commitment-output.json 2> /report/wrong-commitment-error.log; then exit 31; fi
  grep -q 'Migration checkpoint differs from external commitment' /report/wrong-commitment-error.log
  find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/rejection-after.sha256
  cmp /report/rejection-before.sha256 /report/rejection-after.sha256
 else
  NANO_TEST_MIGRATION_STOP="$stage" OUT/migrate --offline-owned-copy "/report/$stage/chain" --audit-request /proof/finalized-audit-request.json > "/report/$stage-interrupted-output.json" 2> "/report/$stage-interrupted-error.log" &
  migration_pid=$!
  seen=0
  for attempt in $(seq 1 300); do
   if grep -q "migration-test-stage:$stage" "/report/$stage-interrupted-error.log"; then seen=1; break; fi
   kill -0 "$migration_pid" || exit 32
   sleep 0.1
  done
  test "$seen" = 1
  kill -KILL "$migration_pid"
  if wait "$migration_pid"; then exit 33; else interrupted_exit=$?; fi
  test "$interrupted_exit" = 137
  printf '%s\\n' "$interrupted_exit" > "/report/$stage-interrupted-exit.txt"
 fi
 OUT/migrate --offline-owned-copy "/report/$stage/chain" --audit-request /proof/finalized-audit-request.json > "/report/$stage-migration.json"
 OUT/migrate --offline-owned-copy "/report/$stage/chain" --audit-request /proof/finalized-audit-request.json > "/report/$stage-idempotent.json"
 OUT/nano audit-capella /config/genesis.json "/report/$stage/chain" /proof/finalized-audit-request.json > "/report/$stage-audit-after.json"
done
cd /source
find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/source-after.sha256
cmp /report/source-before.sha256 /report/source-after.sha256
sha256sum /build/pruning-schema-59fa6530-amd64/libnano_core.a /build/pruning-wan-092a153c-amd64/nano > /report/baseline-after.sha256
cmp /report/baseline-before.sha256 /report/baseline-after.sha256
sha256sum OUT/migrate OUT/nano > /report/programs.txt
'''.replace('OUT',o).replace('BASE',b).replace('LINK',shlex.join(link));(r/'run.sh').write_text(script)
args=prefix+['run','--rm','--name','nano-pruned-migration-20261005','--network','none','--read-only','--cap-drop','ALL','--cap-add','DAC_OVERRIDE','--security-opt','no-new-privileges','--cpus','2','--memory','2g','--mount',f'type=volume,src={volume},dst=/build','--mount',f'type=bind,src={src},dst=/work,readonly','--mount',f'type=bind,src={fixture}/restore-proof/backup/restored,dst=/source,readonly','--mount',f'type=bind,src={fixture}/restore-proof,dst=/proof,readonly','--mount',f'type=bind,src={fixture}/config,dst=/config,readonly','--mount',f'type=bind,src={r},dst=/report','--tmpfs','/tmp:rw,nosuid,nodev,size=128m',image,'bash','/report/run.sh']
with (r/'controller.log').open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180)
(r/'exit.txt').write_text(str(p.returncode)+'\n');raise SystemExit(p.returncode)
