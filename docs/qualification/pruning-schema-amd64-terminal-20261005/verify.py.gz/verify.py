from pathlib import Path
import subprocess,hashlib,json
r=Path(__file__).parent;s=Path('/home/ubuntu/nano-pruning-schema-20261005');b='/build/finalized-retention-4734f285-amd64';o='/build/pruning-schema-59fa6530-amd64';l='/build/coherent-efbeb9bc-amd64';image='sha256:fd9b0bb98a63963dba141a820ab7a49c08e23afcfb7b5ea9ea939987d75d6f14'
assert (r/'controller-exit.txt').read_text().strip()=='0' and (r/'extend-exit.txt').read_text().strip()=='0'
assert subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD'],text=True).strip()=='59fa653033aefb23651c32f1d986ac644e4866d2'
assert not subprocess.check_output(['git','-C',str(s),'status','--porcelain'],text=True).strip()
names=subprocess.check_output(['git','-C',str(s),'ls-files'],text=True).splitlines();actual={n:hashlib.sha256((s/n).read_bytes()).hexdigest() for n in names};assert actual==json.loads((r/'sources-before.json').read_text());(r/'independent-sources.json').write_text(json.dumps(actual,indent=2)+'\n')
args=['sudo','-n','docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--mount','type=volume,src=nano-clean-rpc-build-20261002,dst=/build,readonly',image,'sha256sum',o+'/test',o+'/legacy-reader',o+'/libnano_core.a',o+'/sync',o+'/capella',b+'/libnano_core.a',l+'/libnano_core.a',b+'/nano-execution-checkpoint-tests']
actual=subprocess.check_output(args,text=True);(r/'independent-programs.txt').write_text(actual)
for name in ['programs.txt','baseline-before.txt','baseline-after.txt']:
 for line in (r/name).read_text().splitlines():assert line in actual
expectations={'schema':('pruned-schema-legacy-refusal','legacyPrunedRefused'),'restore':('historical-state-pruning-offline-restore','physicalCopyVerified'),'corruption':('historical-state-pruning-corruption','ownedFixturesOnly'),'checkpoint':('atomic-execution-checkpoint','concurrentCAS'),'pruning-sync':('atomic-historical-state-pruning-sync','markerStateCheckpointAtomic'),'checkpoint-sync':('atomic-execution-checkpoint-sync','retainedAndLostSuffix'),'capella-restore':('capella-pruned-consensus-physical-restore','independentWitnessesRetained')}
results={}
for stage,(scenario,flag) in expectations.items():
 entries=[json.loads(t) for t in (r/(stage+'.log')).read_text().splitlines() if t.startswith('{')];record=next(t for t in entries if t.get('scenario')==scenario);assert record[flag] is True;results[stage]=record
assert results['capella-restore']['journalsAdvanced']==64 and results['capella-restore']['afterFinalizedEpoch']>results['capella-restore']['beforeFinalizedEpoch']
(r/'review.json').write_text(json.dumps({'revision':'59fa653033aefb23651c32f1d986ac644e4866d2','architecture':'amd64','terminalExit':0,'extendTerminalExit':0,'trackedSources':len(names),'independentHashesVerified':True,'oldQualifiedProgramsUnchanged':True,'scenarios':results,'physicalPowerLoss':False,'productionQualified':False},indent=2)+'\n')
print('Independent AMD64 review exit 0')
