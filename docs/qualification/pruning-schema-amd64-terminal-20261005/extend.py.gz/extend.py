from pathlib import Path
import shlex,subprocess,os,json
r=Path(__file__).parent;I='sha256:fd9b0bb98a63963dba141a820ab7a49c08e23afcfb7b5ea9ea939987d75d6f14';V='nano-clean-rpc-build-20261002';b='/build/finalized-retention-4734f285-amd64';o='/build/pruning-schema-59fa6530-amd64'
def read(p):return subprocess.check_output(['sudo','-n','docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--mount',f'type=volume,src={V},dst=/build,readonly',I,'cat',p],text=True)
f={l.split(' = ',1)[0]:shlex.split(l.split(' = ',1)[1]) for l in read(b+'/CMakeFiles/nano-execution-checkpoint-sync-tests.dir/flags.make').splitlines() if ' = ' in l}
a=['clang++']+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-c','/work/tests/test_execution_checkpoint.cpp','-o',o+'/sync.cpp.o'];link=shlex.split(read(b+'/CMakeFiles/nano-execution-checkpoint-sync-tests.dir/link.txt'));link[link.index('CMakeFiles/nano-execution-checkpoint-sync-tests.dir/tests/test_execution_checkpoint.cpp.o')]=o+'/sync.cpp.o';link[link.index('-o')+1]=o+'/sync';link[link.index('libnano_core.a')]=o+'/libnano_core.a'
c=shlex.split(read(b+'/CMakeFiles/nano-capella-transition-tests.dir/link.txt'));c[c.index('CMakeFiles/nano-capella-transition-tests.dir/tests/test_capella_transition.cpp.o')]='/build/pruning-recovery-94535766-amd64/test_capella_transition.cpp.o';c[c.index('-o')+1]=o+'/capella';c[c.index('libnano_core.a')]=o+'/libnano_core.a'
script='set -eu\ncd '+b+'\nexport TMPDIR='+o+'/tmp\n'
for stage,args in [('sync-compile',a),('sync-link',link),('capella-link',c),('pruning-sync',[o+'/sync','--pruning-sync']),('checkpoint-sync',[o+'/sync']),('capella-restore',[o+'/capella','--historical-pruning-restore'])]:script+=shlex.join(args)+' > /report/'+stage+'.log 2>&1\n'
(r/'extend.sh').write_text(script)
with (r/'extend-controller.log').open('w') as log:p=subprocess.run(['sudo','-n','docker','run','--rm','--name','nano-pruning-schema-extend-20261005','--user',f'{os.getuid()}:{os.getgid()}','--network','none','--read-only','--cap-drop','ALL','--cpus','2','--memory','3g','--mount',f'type=volume,src={V},dst=/build','--mount','type=bind,src=/home/ubuntu/nano-pruning-schema-20261005,dst=/work,readonly','--mount',f'type=bind,src={r},dst=/report',I,'bash','/report/extend.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=300)
(r/'extend-exit.txt').write_text(str(p.returncode)+'\n');raise SystemExit(p.returncode)
