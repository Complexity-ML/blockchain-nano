#include "nano/storage.hpp"
#include <iostream>
int main(int argc,char** argv){if(argc!=2)return 2;try{nano::ChainStore store(argv[1],nano::ChainStore::OpenMode::ReadOnly);store.latest();std::cout<<"opened\n";return 0;}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
