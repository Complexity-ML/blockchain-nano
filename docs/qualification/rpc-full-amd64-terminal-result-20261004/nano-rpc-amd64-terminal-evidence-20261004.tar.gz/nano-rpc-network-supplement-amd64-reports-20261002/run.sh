set -eu
build=/build/rpc-full-d1597d9a-amd64/network
export TMPDIR=/tmp
ctest --test-dir "$build" --show-only=json-v1 > /reports/registry.json
find "$build" -maxdepth 1 -type f -perm /111 -print0 | sort -z | xargs -0 sha256sum > /reports/programs-before.sha256
set +e
ctest --test-dir "$build" --no-tests=error --parallel 1 --timeout 120 --output-on-failure --output-junit /reports/results.xml > /reports/tests.log 2>&1
code=$?
set -e
printf '%s\n' "$code" > /reports/ctest-exit.txt
cp "$build/Testing/Temporary/LastTest.log" /reports/LastTest.log
find "$build" -maxdepth 1 -type f -perm /111 -print0 | sort -z | xargs -0 sha256sum > /reports/programs-after.sha256
cmp /reports/programs-before.sha256 /reports/programs-after.sha256
exit "$code"
