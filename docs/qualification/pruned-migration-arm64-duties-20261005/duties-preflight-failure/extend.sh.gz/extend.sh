set -eu
mkdir /build/migration-duties-arm64-20261005
cd /build/finalized-retention-4734f285-arm64
mkdir /build/migration-duties-arm64-20261005/tmp
export TMPDIR=/build/migration-duties-arm64-20261005/tmp
clang++ -DMCL_BINT_ASM_X64=0 -DMCL_DONT_USE_XBYAK -DMCL_FP_BIT=384 -DMCL_FR_BIT=256 -DMCL_MSM=0 -DMCL_PORTABLE=1 -DMCL_USE_LLVM=1 -DNANO_SYNC_FAULT=1 '-DNANO_TEST_SOURCE="/work"' -I/work/include -I/work/third_party -I/work/third_party/mcl/include -I/work/third_party/ckzg/src -I/work/third_party/ckzg/blst/bindings -I/build/finalized-retention-4734f285-arm64/third_party/ckzg/include -O3 -DNDEBUG -std=gnu++20 -c /work/tests/test_capella_transition.cpp -o /build/migration-duties-arm64-20261005/capella.cpp.o > /report/compile.log 2>&1
/usr/bin/clang++ -O3 -DNDEBUG /build/migration-duties-arm64-20261005/capella.cpp.o -o /build/migration-duties-arm64-20261005/capella -Wl,-rpath,/build/finalized-retention-4734f285-arm64 third_party/mcl/bint64.o third_party/mcl/base64.o /build/pruning-schema-59fa6530-arm64/libnano_core.a third_party/ckzg/libnano_ckzg.a libnano-test-sync-fault.so third_party/ckzg/libnano_blst.a third_party/secp256k1/lib/libsecp256k1.a /usr/lib/aarch64-linux-gnu/libgmpxx.so /usr/lib/aarch64-linux-gnu/libgmp.so /usr/lib/aarch64-linux-gnu/libssl.so /usr/lib/aarch64-linux-gnu/libcrypto.so /usr/lib/aarch64-linux-gnu/libicuuc.so -ldl /usr/lib/aarch64-linux-gnu/librocksdb.so lib/libmcl.a > /report/link.log 2>&1
/build/migration-duties-arm64-20261005/capella --historical-pruning-migration /build/pruned-migration-23df7f63-arm64/migrate > /report/test.log 2>&1
sha256sum /build/migration-duties-arm64-20261005/capella /build/pruned-migration-23df7f63-arm64/migrate /build/pruning-schema-59fa6530-arm64/libnano_core.a > /report/programs.txt
