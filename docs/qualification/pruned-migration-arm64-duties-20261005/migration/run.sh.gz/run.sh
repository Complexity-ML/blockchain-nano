set -eu
mkdir /build/pruned-migration-23df7f63-arm64
cd /build/finalized-retention-4734f285-arm64
clang++ -std=c++20 -O2 -I/work/third_party /work/tools/storage-maintenance/migrate-pruned-owned-copy.cpp -lrocksdb -lcrypto -o /build/pruned-migration-23df7f63-arm64/migrate > /report/compile.log 2>&1
/usr/bin/clang++ -O3 -DNDEBUG /build/pruning-wan-092a153c-arm64/main.cpp.o -o /build/pruned-migration-23df7f63-arm64/nano third_party/mcl/bint64.o third_party/mcl/base64.o /build/pruning-schema-59fa6530-arm64/libnano_core.a third_party/ckzg/libnano_ckzg.a third_party/ckzg/libnano_blst.a third_party/secp256k1/lib/libsecp256k1.a /usr/lib/aarch64-linux-gnu/libgmpxx.so /usr/lib/aarch64-linux-gnu/libgmp.so /usr/lib/aarch64-linux-gnu/libssl.so /usr/lib/aarch64-linux-gnu/libcrypto.so /usr/lib/aarch64-linux-gnu/libicuuc.so -ldl /usr/lib/aarch64-linux-gnu/librocksdb.so lib/libmcl.a > /report/link.log 2>&1
sha256sum /build/pruning-schema-59fa6530-arm64/libnano_core.a /build/pruning-wan-092a153c-arm64/nano > /report/baseline-before.sha256
cd /source
find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/source-before.sha256
for stage in normal before-write after-write; do
 cp -a /source "/report/$stage"
 printf 'owned-offline-schema-migration-v1\n' > "/report/$stage/.nano-owned-schema-migration-copy"
 /build/pruning-wan-092a153c-arm64/nano audit-capella /config/genesis.json "/report/$stage/chain" /proof/audit-request.json > "/report/$stage-audit-before.json"
 if [ "$stage" = normal ]; then
  cd /report/normal
  find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/rejection-before.sha256
  if /build/pruned-migration-23df7f63-arm64/migrate --offline-owned-copy /report/normal/chain --audit-request /proof/wrong-audit-request.json > /report/wrong-commitment-output.json 2> /report/wrong-commitment-error.log; then exit 31; fi
  grep -q 'Migration checkpoint differs from external commitment' /report/wrong-commitment-error.log
  find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/rejection-after.sha256
  cmp /report/rejection-before.sha256 /report/rejection-after.sha256
 else
  NANO_TEST_MIGRATION_STOP="$stage" /build/pruned-migration-23df7f63-arm64/migrate --offline-owned-copy "/report/$stage/chain" --audit-request /proof/audit-request.json > "/report/$stage-interrupted-output.json" 2> "/report/$stage-interrupted-error.log" &
  migration_pid=$!
  seen=0
  for attempt in $(seq 1 300); do
   if grep -q "migration-test-stage:$stage" "/report/$stage-interrupted-error.log"; then seen=1; break; fi
   kill -0 "$migration_pid" || exit 32
   sleep 0.1
  done
  test "$seen" = 1
  kill -KILL "$migration_pid"
  if wait "$migration_pid"; then exit 33; else interrupted_exit=$?; fi
  test "$interrupted_exit" = 137
  printf '%s\n' "$interrupted_exit" > "/report/$stage-interrupted-exit.txt"
 fi
 /build/pruned-migration-23df7f63-arm64/migrate --offline-owned-copy "/report/$stage/chain" --audit-request /proof/audit-request.json > "/report/$stage-migration.json"
 /build/pruned-migration-23df7f63-arm64/migrate --offline-owned-copy "/report/$stage/chain" --audit-request /proof/audit-request.json > "/report/$stage-idempotent.json"
 /build/pruned-migration-23df7f63-arm64/nano audit-capella /config/genesis.json "/report/$stage/chain" /proof/audit-request.json > "/report/$stage-audit-after.json"
done
cd /source
find . -type f -print0 | sort -z | xargs -0 sha256sum > /report/source-after.sha256
cmp /report/source-before.sha256 /report/source-after.sha256
sha256sum /build/pruning-schema-59fa6530-arm64/libnano_core.a /build/pruning-wan-092a153c-arm64/nano > /report/baseline-after.sha256
cmp /report/baseline-before.sha256 /report/baseline-after.sha256
sha256sum /build/pruned-migration-23df7f63-arm64/migrate /build/pruned-migration-23df7f63-arm64/nano > /report/programs.txt
